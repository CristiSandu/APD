package com.apd.tema2.intersections;

import com.apd.tema2.Main;
import com.apd.tema2.entities.Car;
import com.apd.tema2.entities.Intersection;


import java.util.LinkedList;
import java.util.Queue;
import java.util.Vector;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;

public class IntersectionC10 implements Intersection {
    int x;

    CyclicBarrier bar;
    Queue<Car> sens1 = new LinkedList<Car>();
    Queue<Car> sens2 = new LinkedList<Car>();

    AtomicInteger curentPass;


    public IntersectionC10() {

        bar = new CyclicBarrier(Main.carsNo);
    }

    /*public void setSemaphore(){
        sem = new Semaphore(-Main.carsNo + 1);
    }*/
    public int getX() {
        return x;
    }
    public CyclicBarrier getBar() {
        return bar;
    }

    public int getCurentPass(){
        return curentPass.get();
    }

    public void setCurentPass(int x){
        curentPass.set(x);
    }

/*
    public void setLastElem(int x) {
        this.lastElem.set(x) ;
    }
    public int getLastElem() {
        return lastElem.get();
    }

    public int getPedestrians() {
        return n;
    }*/

    public Queue<Car> getQueue1() {
        return sens1;
    }
    public void setQueue1(Car car) {
        sens1.add(car);
    }

    public void setQueue2(Car car) {
        sens2.add(car);
    }

    public Queue<Car> getQueue2() {
        return sens2;
    }

}
