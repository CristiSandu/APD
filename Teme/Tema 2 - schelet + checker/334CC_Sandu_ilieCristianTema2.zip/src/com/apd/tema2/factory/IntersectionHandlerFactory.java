package com.apd.tema2.factory;

import com.apd.tema2.Main;
import com.apd.tema2.entities.*;
import com.apd.tema2.intersections.*;
import com.apd.tema2.utils.Constants;

import java.util.Vector;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.Executor;
import java.util.concurrent.Semaphore;

import static java.lang.Thread.sleep;

/**
 * Clasa Factory ce returneaza implementari ale InterfaceHandler sub forma unor
 * clase anonime.
 */
public class IntersectionHandlerFactory {

    public static IntersectionHandler getHandler(String handlerType) {
        // simple semaphore intersection
        // max random N cars roundabout (s time to exit each of them)
        // roundabout with exactly one car from each lane simultaneously
        // roundabout with exactly X cars from each lane simultaneously
        // roundabout with at most X cars from each lane simultaneously
        // entering a road without any priority
        // crosswalk activated on at least a number of people (s time to finish all of
        // them)
        // road in maintenance - 2 ways 1 lane each, X cars at a time
        // road in maintenance - 1 way, M out of N lanes are blocked, X cars at a time
        // railroad blockage for s seconds for all the cars
        // unmarked intersection
        // cars racing
        return switch (handlerType) {
            case "simple_semaphore" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    String start = "Car " + car.getId() + " has reached the semaphore, now waiting...";
                    System.out.println(start);
                    try {
                        sleep(car.getWaitingTime());
                    } catch (Exception ex) {
                    }

                    String end = "Car " + car.getId() + " has waited enough, now driving...";
                    System.out.println(end);
                }
            };
            case "simple_n_roundabout" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    IntersectionC2 inter = (IntersectionC2) Main.intersection;
                    String start = "Car " + car.getId() + " has reached the roundabout, now waiting...";
                    System.out.println(start);

                    try {
                        inter.getSemaphor().acquire();
                    } catch (InterruptedException exc) {

                    }

                    String middel = "Car " + car.getId() + " has entered the roundabout";
                    System.out.println(middel);


                    try {
                        sleep(inter.getTime());
                    } catch (Exception ex) {
                    }
                    String end = "Car " + car.getId() + " has exited the roundabout after " + inter.getTime() / 1000 + " seconds";
                    System.out.println(end);
                    inter.getSemaphor().release();
                }
            };
            case "simple_strict_1_car_roundabout" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    IntersectionC3 inter = (IntersectionC3) Main.intersection;
                    Vector<Semaphore> semS = inter.getSemaphors();

                    String start = "Car " + car.getId() + " has reached the roundabout";
                    System.out.println(start);

                    try {
                        semS.get(car.getPriority()).acquire();
                    } catch (InterruptedException exc) {

                    }

                    String middel = "Car " + car.getId() + " has entered the roundabout from lane " + car.getPriority();
                    System.out.println(middel);


                    try {
                        sleep(inter.getTime());
                    } catch (Exception ex) {
                    }
                    String end = "Car " + car.getId() + " has exited the roundabout after " + inter.getTime() / 1000 + " seconds";
                    System.out.println(end);
                    semS.get(car.getPriority()).release();


                }
            };
            case "simple_strict_x_car_roundabout" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    IntersectionC4 inter = (IntersectionC4) Main.intersection;
                    Vector<Semaphore> semS = inter.getSemaphors();

                    String start = "Car " + car.getId() + " has reached the roundabout, now waiting...";
                    System.out.println(start);

                    try {
                        inter.getCyclicBarr().await();
                    } catch (InterruptedException | BrokenBarrierException e) {
                        e.printStackTrace();
                    }

                    try {
                        semS.get(car.getStartDirection()).acquire();
                    } catch (InterruptedException exc) {

                    }


                    String middel1 = "Car " + car.getId() + " was selected to enter the roundabout from lane " + car.getStartDirection();
                    System.out.println(middel1);
                    try {
                        inter.getCyclicBarr2().await();
                    } catch (InterruptedException | BrokenBarrierException e) {
                        e.printStackTrace();
                    }

                    String middel2 = "Car " + car.getId() + " has entered the roundabout from lane " + car.getStartDirection();
                    System.out.println(middel2);
                    try {
                        inter.getCyclicBarr2().await();
                    } catch (InterruptedException | BrokenBarrierException e) {
                        e.printStackTrace();
                    }


                    try {
                        sleep(inter.getTime());
                    } catch (Exception ex) {
                    }
                    String end = "Car " + car.getId() + " has exited the roundabout after " + inter.getTime() / 1000 + " seconds";
                    System.out.println(end);
                    try {
                        inter.getCyclicBarr2().await();
                    } catch (InterruptedException | BrokenBarrierException e) {
                        e.printStackTrace();
                    }
                    semS.get(car.getStartDirection()).release();
                }
            };
            case "simple_max_x_car_roundabout" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    // Get your Intersection instance

                    try {
                        sleep(car.getWaitingTime());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } // NU MODIFICATI

                    IntersectionC4 inter = (IntersectionC4) Main.intersection;
                    Vector<Semaphore> semS = inter.getSemaphors();

                    String start = "Car " + car.getId() + " has reached the roundabout from lane " + car.getStartDirection();
                    System.out.println(start);

                    try {
                        inter.getCyclicBarr().await();
                    } catch (InterruptedException | BrokenBarrierException e) {
                        e.printStackTrace();
                    }

                    try {
                        semS.get(car.getStartDirection()).acquire();
                    } catch (InterruptedException exc) {

                    }

                    String middel2 = "Car " + car.getId() + " has entered the roundabout from lane " + car.getStartDirection();
                    System.out.println(middel2);

                    try {
                        sleep(inter.getTime());
                    } catch (Exception ex) {
                    }
                    String end = "Car " + car.getId() + " has exited the roundabout after " + inter.getTime() / 1000 + " seconds";
                    System.out.println(end);

                    semS.get(car.getStartDirection()).release();
                }
            };
            case "priority_intersection" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    // Get your Intersection instance

                    try {
                        sleep(car.getWaitingTime());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } // NU MODIFICATI

                    // Continuati de aici
                }
            };
            case "crosswalk" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    String green = "Car " + car.getId() + " has now green light";
                    String red = "Car " + car.getId() + " has now red light";
                    IntersectionC7 inter = (IntersectionC7) Main.intersection;

                    while (!Main.pedestrians.isFinished()) {
                        // System.out.println(Main.pedestrians.isFinished());
                        inter.getSemaphor().release();
                        if (Main.pedestrians.isPass()) {
                            if (inter.getLastElem() == 1) {
                                System.out.println(red);
                                inter.setLastElem(0);
                            }
                        } else {
                            if (inter.getLastElem() == 0) {
                                System.out.println(green);
                                inter.setLastElem(1);
                            }
                        }
                        inter.setSemaphore();
                    }
                }
            };
            case "simple_maintenance" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    String start = "Car " + car.getId() + " from side number " + car.getStartDirection() + " has reached the bottleneck";
                    String end = "Car " + car.getId() + " from side number " + car.getStartDirection() + " has passed the bottleneck";
                    System.out.println(start);
                    IntersectionC8 inter = (IntersectionC8) Main.intersection;
                    if (car.getStartDirection() == 0) {
                        try {
                            inter.getSemaphor1().acquire();
                        } catch (InterruptedException ex) {
                        }
                        //   System.out.println("test asdfsgfhgjhfgfh");
                        try {
                            inter.getBar(inter.getCurentPass()).await();
                        } catch (InterruptedException | BrokenBarrierException ex2) {

                        }
                        //   System.out.println("test asdfsgfhgjhfgfh bariera ");

                        //inter.setCurentPass(1);
                        System.out.println(end);
                        inter.getSemaphor2().release();
                    } else if (car.getStartDirection() == 1) {
                        try {
                            inter.getSemaphor2().acquire();
                        } catch (InterruptedException ex) {
                        }

                        try {
                            inter.getBar(inter.getCurentPass()).await();
                        } catch (InterruptedException | BrokenBarrierException ex2) {

                        }
                        // inter.setCurentPass(0);
                        System.out.println(end);
                        inter.getSemaphor1().release();
                    }
                }
            };
            case "complex_maintenance" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {

                }
            };
            case "railroad" -> new IntersectionHandler() {
                @Override
                public void handle(Car car) {
                    String start = "Car " + car.getId() + " from side number " + car.getStartDirection() + " has stopped by the railroad";
                    String middle = "The train has passed, cars can now proceed";
                    String end = "Car " + car.getId() + " from side number " + car.getStartDirection() + " has started driving";
                    System.out.println(start);

                    IntersectionC10 inter = (IntersectionC10) Main.intersection;
                    if (car.getStartDirection() == 0)
                    {
                        inter.setQueue1(car);
                    }else if (car.getStartDirection() == 1)
                    {
                        inter.setQueue2(car);
                    }
                    try {
                        inter.getBar().await();
                    } catch (InterruptedException | BrokenBarrierException ex2) {

                    }
                    if (car.getId() == 0) {
                        int max;
                        System.out.println(middle);
                        while (inter.getQueue1().size()!=0){
                            Car care = inter.getQueue1().poll();
                            String end1 = "Car " + care.getId() + " from side number " + care.getStartDirection() + " has started driving";
                            System.out.println(end1);
                            /*Car car1 = inter.getQueue2().poll();
                            String end2 = "Car " + car1.getId() + " from side number " + car1.getStartDirection() + " has started driving";
                            System.out.println(end2);*/

                        }
                        while (inter.getQueue2().size()!=0){
                             /*Car care = inter.getQueue1().poll();
                            String end1 = "Car " + care.getId() + " from side number " + care.getStartDirection() + " has started driving";
                            System.out.println(end1);*/

                            Car car1 = inter.getQueue2().poll();
                            String end2 = "Car " + car1.getId() + " from side number " + car1.getStartDirection() + " has started driving";
                            System.out.println(end2);

                        }
                    }

                }
            };
            default -> null;
        };
    }
}
