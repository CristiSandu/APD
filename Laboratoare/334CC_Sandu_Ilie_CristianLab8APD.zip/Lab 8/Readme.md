## Laborator 8 MPI
